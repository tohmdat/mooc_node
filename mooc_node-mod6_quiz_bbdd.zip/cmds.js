const {log, biglog, errorlog, colorize} = require('./out');

const model = require('./model');

/**
 * Muestra la ayuda.
 *
 * @param rl Objeto readline usado para implementar el CLI.
 */
exports.helpCmd = rl => {
    log('Commandos:');
    log('  h|help - Muestra esta ayuda.');
    log('  list - Listar los quizzes existentes.');
    log('  show <id> - Muestra la pregunta y la respuesta el quiz indicado.');
    log('  add - Añadir un nuevo quiz interactivamente.');
    log('  delete <id> - Borrar el quiz indicado.');
    log('  edit <id> - Editar el quiz indicado.');
    log('  test <id> - Probar el quiz indicado.');
    log('  p|play - Jugar a preguntar aleatoriamente todos los quizzes.');
    log('  credits - Créditos.');
    log('  q|quit - Salir del programa.');
    rl.prompt();
};

/**
 * Lista todos los quizzes existentes en el modelo.
 *
 * @param rl Objeto readline usado para implementar el CLI.
 */
exports.listCmd = rl => {
    model.getAll()
        .then( quizzes => {
            quizzes.forEach((quiz) => {
                log(` [${colorize(quiz.id, 'magenta')}]:  ${quiz.question}`);
            });
            rl.prompt();
        })
        .catch( err => {
            errorlog(`error bbdd: ${err}`);
            rl.prompt();
        });
};


/**
 * Muestra el quiz indicado en el parámetro: la pregunta y la respuesta.
 *
 * @param rl Objeto readline usado para implementar el CLI.
 * @param id Clave del quiz a mostrar.
 */
exports.showCmd = (rl, id) => {
    if (typeof id === 'undefined') {
        errorlog('Falta el parámetro id.');
        rl.prompt();
    } else {
        model.getByIndex(id)
            .then(quiz => {
                log(` [${colorize(id, 'magenta')}]:  ${quiz.question} ${colorize('=>', 'magenta')} ${quiz.answer}`);
                rl.prompt();
            })
            .catch( err => {
                errorlog(`error bbdd: ${err}`);
                rl.prompt();
            });
    }
};


/**
 * Añade un nuevo quiz al módelo.
 * Pregunta interactivamente por la pregunta y por la respuesta.
 *
 * Hay que recordar que el funcionamiento de la funcion rl.question es asíncrono.
 * El prompt hay que sacarlo cuando ya se ha terminado la interacción con el usuario,
 * es decir, la llamada a rl.prompt() se debe hacer en la callback de la segunda
 * llamada a rl.question.
 *
 * @param rl Objeto readline usado para implementar el CLI.
 */
exports.addCmd = rl => {
    rl.question(colorize(' Introduzca una pregunta: ', 'red'), question => {
        rl.question(colorize(' Introduzca la respuesta ', 'red'), answer => {
            model.add(question, answer)
                .then(() => {
                    log(` ${colorize('Se ha añadido', 'magenta')}: ${question} ${colorize('=>', 'magenta')} ${answer}`);
                    rl.prompt();
                })
                .catch( err => {
                    errorlog(`error bbdd: ${err}`);
                    rl.prompt();
                });
        });
    });
};


/**
 * Borra un quiz del modelo.
 *
 * @param rl Objeto readline usado para implementar el CLI.
 * @param id Clave del quiz a borrar en el modelo.
 */
exports.deleteCmd = (rl, id) => {
    if (typeof id === 'undefined') {
        errorlog('Falta el parámetro id.');
        rl.prompt();
    } else {
        model.deleteByIndex(id)
            .then( n => {
                if (n !== 1) {
                    errorlog(`No se ha encontrado el elemento ${id}`);
                }
                rl.prompt();
            })
            .catch( err => {
                errorlog(`error bbdd: ${err}`);
                rl.prompt();
            });
    }
};


/**
 * Edita un quiz del modelo.
 *
 * Hay que recordar que el funcionamiento de la funcion rl.question es asíncrono.
 * El prompt hay que sacarlo cuando ya se ha terminado la interacción con el usuario,
 * es decir, la llamada a rl.prompt() se debe hacer en la callback de la segunda
 * llamada a rl.question.
 *
 * @param rl Objeto readline usado para implementar el CLI.
 * @param id Clave del quiz a editar en el modelo.
 */
exports.editCmd = (rl, id) => {
    if (typeof id === 'undefined') {
        errorlog('Falta el parámetro id.');
        rl.prompt();
    } else {
        try {
            model.getByIndex(id)
                .then( quiz => {
                    if (quiz) {
                        process.stdout.isTTY && setTimeout(() => {rl.write(quiz.question);},0);

                        rl.question(colorize(' Introduzca una pregunta: ', 'red'), question => {
            
                            process.stdout.isTTY && setTimeout(() => {rl.write(quiz.answer);},0);
            
                            rl.question(colorize(' Introduzca la respuesta ', 'red'), answer => {
                                model.update(id, question, answer)
                                    .then( n => {
                                        if (n[0] === 1) {
                                            log(` Se ha cambiado el quiz ${colorize(id, 'magenta')} por: ${question} ${colorize('=>', 'magenta')} ${answer}`);
                                        } else {
                                            errorlog(`No se ha encontrado la pregunta ${id} en la bbdd`);
                                        }
                                        rl.prompt();
                                    })
                                    .catch( err => {
                                        errorlog(`error bbdd: ${err}`);
                                        rl.prompt();
                                    });                               
                            });
                        });
                    } else {
                        errorlog(`no se ha encontrado la pregunta ${id}`);
                    }
                })
                .catch( err => {
                    errorlog(`error bbdd: ${err}`);
                    rl.prompt();
                });
        } catch (error) {
            errorlog(error.message);
            rl.prompt();
        }
    }
};


/**
 * Prueba un quiz, es decir, hace una pregunta del modelo a la que debemos contestar.
 *
 * @param rl Objeto readline usado para implementar el CLI.
 * @param id Clave del quiz a probar.
 */
exports.testCmd = (rl, id) => {
    if (!id) {
        errorlog('Falta el parámetro id.');
        rl.prompt();
    } else {
        try {
            model.getByIndex(id)
                .then( quiz => {
                    rl.question(colorize(quiz.question + '? ' , 'red'), answer => {
                        if (answer.trim().toUpperCase() === quiz.answer.toUpperCase()) {
                            log('Su respuesta es correcta');
                            biglog('Correcta', 'green');
                        } else {
                            log('Su respuesta es incorecta');
                            biglog('Incorrecta', 'red');
                        }
                        rl.prompt();
                    });
                })
                .catch( err => {
                    errorlog(`error bbdd: ${err}`);
                    rl.prompt();
                });
        } catch (error) {
            errorlog(error.message);
            rl.prompt();
        }
    }
};

/**
 * Pregunta todos los quizzes existentes en el modelo en orden aleatorio.
 * Se gana si se contesta a todos satisfactoriamente.
 *
 * @param rl Objeto readline usado para implementar el CLI.
 */
exports.playCmd = async rl => {
    try {
        let score = 0;

        let random = (await model.getAll()).sort(() => Math.random() - 0.5);

        for (let quiz of random) {
            let answer = await new Promise((resolve) => {
                rl.question(colorize(quiz.question + '? ' , 'red'), answer => {
                    resolve(answer);
                });
            });
            if (answer.trim().toUpperCase() === quiz.answer.toUpperCase()) {
                log(`CORRECTO - Lleva ${++score} aciertos.`);
            } else {
                log(`INCORRECTO.\nFin del juego. Aciertos: ${score}`);
                break;
            }          
        }
        if (score === random.length) {
            log(`No hay nada más que preguntar.\nFin del juego. Aciertos: ${score}`);
        }
        rl.prompt();
    } catch (error) {
        errorlog(error.message);
        rl.prompt();
    }
};

/**
 * Muestra los nombres de los autores de la práctica.
 *
 * @param rl Objeto readline usado para implementar el CLI.
 */
exports.creditsCmd = rl => {
    log('Autores de la práctica:');
    log('Francisco Carrasco', 'green');
    rl.prompt();
};

/**
 * Terminar el programa.
 *
 * @param rl Objeto readline usado para implementar el CLI.
 */
exports.quitCmd = rl => {
    rl.close();
};

