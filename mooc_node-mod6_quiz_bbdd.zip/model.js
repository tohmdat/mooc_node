// Nombre del fichero donde se guardan las preguntas.
// Es una base de datos sqlite
const DB_FILENAME = 'quizzes.sqlite';

const Sequelize = require('sequelize');
const options = { logging: false, operatorsAliases: false};
const sequelize = new Sequelize(`sqlite:${DB_FILENAME}`, options);
const quiz = sequelize.define(
    'quiz', {
        question: Sequelize.STRING,
        answer: Sequelize.STRING
    }
);


// Datos inciales
let initial_quizzes = [
    {
        question: 'Capital de Italia',
        answer: 'Roma'
    },
    {
        question: 'Capital de Francia',
        answer: 'París'
    },
    {
        question: 'Capital de España',
        answer: 'Madrid'
    },
    {
        question: 'Capital de Portugal',
        answer: 'Lisboa'
    }
];


/**
   Comprueba que existe la bbdd de preguntas, y si no la crea con datos iniciales
 */
const load = () => {

    sequelize.sync()
        .then(() => quiz.count())
        .then((count) => {
            if (count === 0) {
                return quiz.bulkCreate(initial_quizzes);
            }
        })
        .catch( err => {
            throw err;
        });
};


//
/**
 * Devuelve el número total de preguntas existentes.
 *
 * @returns {number} número total de preguntas existentes.
 */
exports.count = () => {
    return quiz.count();
};

/**
 * Añade un nuevo quiz.
 *
 * @param question String con la pregunta.
 * @param answer   String con la respuesta.
 */
exports.add = (question, answer) => {
    return quiz.create({question, answer});
};


/**
 * Actualiza el quiz situado en la posicion index.
 *
 * @param id       Clave que identifica el quiz a actualizar.
 * @param question String con la pregunta.
 * @param answer   String con la respuesta.
 */
exports.update = (id, question, answer) => {
    return quiz.update( {question, answer}, {where: {id}});
};

/**
 * Devuelve todos los quizzes existentes.
 *
 * Devuelve un clon del valor guardado en la variable quizzes, es decir devuelve un
 * objeto nuevo con todas las preguntas existentes.
 * Para clonar quizzes se usa stringify + parse.
 *
 * @returns {any}
 */
exports.getAll = () => quiz.findAll();


/**
 * Devuelve un clon del quiz almacenado en la posición dada.
 *
 * Para clonar el quiz se usa stringify + parse.
 *
 * @param id Clave que identifica el quiz a devolver.
 *
 * @returns {question, answer} Devuelve el objeto quiz de la posición dada
 */
exports.getByIndex = id => {
    return quiz.findOne( {where: {id}});
};

//
/**
 * Elimina el quiz situado en la posición dada.
 *
 * @param id Clave que identifica el quiz a borrar.
 */
exports.deleteByIndex = id => {
    return quiz.destroy( {where: {id}});
};


// Carga los quizzes almacenados en el fichero.
load();


